//
//  CustomerDocument.h
//  Cloud4WiSDKWiFi
//

#ifndef CustomerDocument_h
#define CustomerDocument_h

@interface CustomerDocument : NSObject

@property NSString *memberId;
@property NSString *number;
@property NSString *passportNumber;
@property NSString *personalId;
@property NSString *type;

@end

#endif /* CustomerDocument_h */
